#include <iostream>
#include "display.h"





using namespace std;

int main() {


    display game;
    game.initGame();
    return 0;
}
